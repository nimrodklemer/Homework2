public class Unit extends Tile{

    public String name;
    public Integer healthPool;
    public Integer healthAmount;
    public Integer attackPoints;
    public Integer defensePoints;
    public Unit(char t, int x, int y, String n){
        super(t,x,y);
        name = n;
    }

    public String getName(){
        return name;
    }

    public String description(){
        return "Name: " + name +
                "\nHealth Pool: " + healthPool +
                "\nHealth Amount: " + healthAmount +
                "\nAttack Points: " + attackPoints +
                "\nDefense Points: " + defensePoints;
    }

}
