public class EmptySpace extends Tile{
    public EmptySpace(int x, int y){
        super('.', x, y);
    }
}
