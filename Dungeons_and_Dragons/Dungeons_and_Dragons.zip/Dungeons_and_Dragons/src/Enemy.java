public class Enemy extends Unit{
    public Integer experienceValue;
    public Enemy(char t, int x, int y, String n, Integer ev) {
        super(t, x, y, n);
        experienceValue = ev;
    }
}
