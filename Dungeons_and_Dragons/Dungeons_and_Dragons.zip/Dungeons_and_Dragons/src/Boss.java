public class Boss extends Monster implements HeroicUnit{

    Integer abilityFrequency;
    Integer combatTicks;

    public Boss(char t, int x, int y, String n, Integer ev, Integer vr, Integer af) {
        super(t, x, y, n, ev, vr);
        abilityFrequency = af;
        combatTicks = 0;
    }

    @Override
    public void castAbility() {
        return;
    }
}
