public class Rogue extends Player{
    public Rogue(int x, int y, String n) {
        super(x, y, n);
    }
}
