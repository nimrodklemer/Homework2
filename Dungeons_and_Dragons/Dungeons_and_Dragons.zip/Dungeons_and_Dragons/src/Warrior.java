public class Warrior extends Player{

    Integer remainingCooldown;
    Integer abilityCooldown;

    public Warrior(int x, int y, String n, Integer ac) {
        super(x, y, n);
        abilityCooldown = ac;
        remainingCooldown = 0;
    }

    @Override
    public String toString() {
        return "Warrior";
    }

    @Override
    public String description() {
        return super.description() +
                "\nRemaining Cooldown: " + remainingCooldown +
                "\nAbility Cooldown: " + abilityCooldown;
    }

    @Override
    public void onTick() {
        super.onTick();
    }
}
