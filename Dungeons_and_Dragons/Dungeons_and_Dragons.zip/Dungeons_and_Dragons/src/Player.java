public class Player extends Unit implements HeroicUnit{

    Integer experience;
    Integer playerLevel;
    public Player(int x, int y, String n) {
        super('@', x, y, n);
        experience = 0;
        playerLevel = 1;
    }

    @Override
    public String description() {
        return super.description() +
                "\nExperience: " + experience +
                "\nLevel: " + playerLevel;
    }

    @Override
    public void castAbility() {
        return;
    }
}
