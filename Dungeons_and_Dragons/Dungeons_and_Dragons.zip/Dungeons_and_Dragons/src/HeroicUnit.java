public interface HeroicUnit {
    public void castAbility();
}
