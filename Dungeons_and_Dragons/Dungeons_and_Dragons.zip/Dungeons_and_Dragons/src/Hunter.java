public class Hunter extends Player{
    public Hunter(int x, int y, String n) {
        super(x, y, n);
    }
}
