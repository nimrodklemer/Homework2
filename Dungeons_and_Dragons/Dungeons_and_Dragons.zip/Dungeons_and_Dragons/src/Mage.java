public class Mage extends Player{
    public Mage(int x, int y, String n) {
        super(x, y, n);
    }
}
