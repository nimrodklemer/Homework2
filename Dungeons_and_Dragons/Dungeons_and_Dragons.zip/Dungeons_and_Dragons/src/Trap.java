public class Trap extends Enemy{
    Integer visibilityTime;
    Integer invisibilityTime;
    Integer ticksCount;
    Boolean visible;

    public Trap(char t, int x, int y, String n, Integer ev, Integer vt, Integer it) {
        super(t, x, y, n, ev);
        visibilityTime = vt;
        invisibilityTime = it;
        ticksCount = 0;
        visible = true;
    }
}
