public class GameBoard {
    Tile[][] board;

    public GameBoard(Tile[][] b){
        board = b;
    }
}
