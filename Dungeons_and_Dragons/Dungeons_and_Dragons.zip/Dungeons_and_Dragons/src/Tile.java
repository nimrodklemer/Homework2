public class Tile {
    char tile;
    int[] position;

    public Tile(char t, int x, int y){
        tile = t;
        position = new int[]{x,y};
    }

    public String toString(){
        return String.valueOf(tile);
    }

    public void onTick(){
        return;
    }
}
