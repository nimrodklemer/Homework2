public class Monster extends Enemy{
    Integer visionRange;

    public Monster(char t, int x, int y, String n, Integer ev, Integer vr) {
        super(t, x, y, n, ev);
        visionRange = vr;
    }
}
